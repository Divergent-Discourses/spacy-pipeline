| Feature | Description |
| --- | --- |
| **Name** | `bo_core_news_lg` |
| **Version** | `0.0.7` |
| **spaCy** | `>=3.8.7,<3.9.0` |
| **Default Pipeline** | `ner`, `tok2vec`, `morphologizer` |
| **Components** | `ner`, `tok2vec`, `morphologizer` |
| **Vectors** | 0 keys, 0 unique vectors (0 dimensions) |
| **Sources** | n/a |
| **License** | n/a |
| **Author** | [n/a]() |

### Label Scheme

<details>

<summary>View label scheme (30 labels for 2 components)</summary>

| Component | Labels |
| --- | --- |
| **`ner`** | `EVENT`, `LOC`, `MISC`, `MONEY`, `NUM`, `ORG`, `PER`, `POSITION`, `QUANTITY`, `SLOGAN`, `SOC`, `TIME`, `TITLE` |
| **`morphologizer`** | `POS=PUNCT`, `POS=NOUN`, `POS=ADV`, `POS=ADP`, `POS=CCONJ`, `POS=PRON`, `POS=VERB`, `POS=DET`, `POS=AUX`, `POS=SCONJ`, `POS=PART`, `POS=ADJ`, `POS=PROPN`, `POS=NUM`, `POS=INTJ`, `POS=SYM`, `POS=X` |

</details>